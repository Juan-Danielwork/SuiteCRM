<?php
// created: 2023-11-13 05:00:49
$GLOBALS['tabStructure'] = array (
  'LBL_TABGROUP_SALES' => 
  array (
    'label' => 'LBL_TABGROUP_SALES',
    'modules' => 
    array (
      0 => 'Opportunities',
    ),
  ),
  'LBL_TABGROUP_MARKETING' => 
  array (
    'label' => 'LBL_TABGROUP_MARKETING',
    'modules' => 
    array (
      0 => 'Accounts',
      1 => 'Contacts',
    ),
  ),
  'LBL_TABGROUP_SUPPORT' => 
  array (
    'label' => 'LBL_TABGROUP_SUPPORT',
    'modules' => 
    array (
      0 => 'CB4IN_Invoice',
      1 => 'C2011_Payment',
    ),
  ),
  'LBL_TABGROUP_ACTIVITIES' => 
  array (
    'label' => 'LBL_TABGROUP_ACTIVITIES',
    'modules' => 
    array (
      0 => 'C4SET_ITBMS',
      1 => 'C4SET_Edificio',
      2 => 'C4SET_Barriada',
      3 => 'C4SET_Corregimiento',
      4 => 'C4SET_Torre',
    ),
  ),
);