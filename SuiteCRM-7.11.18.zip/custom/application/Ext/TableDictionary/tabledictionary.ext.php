<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c2011_payment_opportunitiesMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c2011_payment_securitygroups_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c4set_barriada_opportunitiesMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c4set_corregimiento_opportunitiesMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c4set_edificio_opportunitiesMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c4set_torre_opportunitiesMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ca30_cost_opportunitiesMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/cb4in_invoice_accountsMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/cb4in_invoice_opportunitiesMetaData.php');


?>