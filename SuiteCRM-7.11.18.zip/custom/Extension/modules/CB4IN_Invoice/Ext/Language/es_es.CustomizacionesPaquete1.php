<?php 
 // created: 2020-12-05 22:59:14
$mod_strings['LBL_CB4IN_INVOICE_ACCOUNTS_FROM_ACCOUNTS_TITLE'] = 'Cuenta';
$mod_strings['LBL_CB4IN_INVOICE_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Número de Avaluo';
$mod_strings['LBL_FECHA_DE_FACTURA'] = 'Fecha de Factura';
$mod_strings['LBL_FECHA_FACTURA_'] = 'Fecha Factura';
$mod_strings['LBL_INVOICE_DATE'] = 'Fecha de Factura';
$mod_strings['LBL_FECHA_FACTURA '] = 'Fecha Factura';
$mod_strings['LBL_NUMERO_AVALUO'] = 'Numero de Avaluo';
$mod_strings['LBL_DATE_CREATED_1'] = 'Fecha Inicial de Avaluo';
$mod_strings['LBL_COSTO_AVALUO'] = 'Costo de Avaluo';

?>
