<?php
 // created: 2020-12-05 23:13:53
$dictionary['CB4IN_Invoice']['fields']['invoice_date_c']['inline_edit']=1;

 ?>