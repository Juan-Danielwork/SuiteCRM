<?php
 // created: 2020-12-24 14:18:16
$dictionary['CB4IN_Invoice']['fields']['name']['inline_edit']=true;
$dictionary['CB4IN_Invoice']['fields']['name']['duplicate_merge']='disabled';
$dictionary['CB4IN_Invoice']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['CB4IN_Invoice']['fields']['name']['merge_filter']='disabled';
$dictionary['CB4IN_Invoice']['fields']['name']['unified_search']=false;

 ?>