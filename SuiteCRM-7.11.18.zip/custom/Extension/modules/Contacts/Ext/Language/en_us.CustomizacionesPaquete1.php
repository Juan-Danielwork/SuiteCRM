<?php 
 // created: 2020-12-05 22:59:14
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Cliente (Empresa)';

?>
