<?php
 // created: 2020-12-30 11:55:58
$dictionary['Contact']['fields']['email1']['required']=true;
$dictionary['Contact']['fields']['email1']['audited']=true;
$dictionary['Contact']['fields']['email1']['inline_edit']=true;
$dictionary['Contact']['fields']['email1']['merge_filter']='disabled';

 ?>