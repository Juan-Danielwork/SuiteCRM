<?php
//auto-generated file DO NOT EDIT
$layout_defs['Opportunities']['subpanel_setup']['c2011_payment_opportunities']['override_subpanel_name'] = 'Opportunity_subpanel_c2011_payment_opportunities';
?>