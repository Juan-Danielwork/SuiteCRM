<?php
//auto-generated file DO NOT EDIT
$layout_defs['Opportunities']['subpanel_setup']['cb4in_invoice_opportunities']['override_subpanel_name'] = 'Opportunity_subpanel_cb4in_invoice_opportunities';
?>