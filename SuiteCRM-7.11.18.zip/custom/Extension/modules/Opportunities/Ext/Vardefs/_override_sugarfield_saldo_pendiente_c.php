<?php
 // created: 2020-12-05 23:13:54
$dictionary['Opportunity']['fields']['saldo_pendiente_c']['inline_edit']=1;

 ?>