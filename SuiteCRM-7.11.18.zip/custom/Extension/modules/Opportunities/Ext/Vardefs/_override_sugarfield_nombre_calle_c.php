<?php
 // created: 2021-01-19 20:38:05
$dictionary['Opportunity']['fields']['nombre_calle_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['nombre_calle_c']['labelValue']='Calle';

 ?>