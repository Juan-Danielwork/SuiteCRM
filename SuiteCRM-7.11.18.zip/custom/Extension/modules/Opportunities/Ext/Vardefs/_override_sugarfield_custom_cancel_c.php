<?php
 // created: 2021-03-26 08:57:03
$dictionary['Opportunity']['fields']['custom_cancel_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['custom_cancel_c']['labelValue']='Excluir fin. y can.';

 ?>