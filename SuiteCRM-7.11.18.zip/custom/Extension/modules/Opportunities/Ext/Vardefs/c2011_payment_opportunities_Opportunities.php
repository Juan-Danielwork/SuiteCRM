<?php
// created: 2020-12-05 22:06:07
$dictionary["Opportunity"]["fields"]["c2011_payment_opportunities"] = array (
  'name' => 'c2011_payment_opportunities',
  'type' => 'link',
  'relationship' => 'c2011_payment_opportunities',
  'source' => 'non-db',
  'module' => 'C2011_Payment',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_C2011_PAYMENT_OPPORTUNITIES_FROM_C2011_PAYMENT_TITLE',
);
