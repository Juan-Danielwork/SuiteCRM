<?php
 // created: 2023-11-11 08:50:39
$dictionary['Opportunity']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>