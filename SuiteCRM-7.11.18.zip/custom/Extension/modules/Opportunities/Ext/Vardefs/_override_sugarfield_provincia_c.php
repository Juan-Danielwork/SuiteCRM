<?php
 // created: 2020-12-12 22:31:14
$dictionary['Opportunity']['fields']['provincia_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['provincia_c']['labelValue']='Provincia';

 ?>