<?php
 // created: 2022-01-05 00:12:03
$dictionary['Opportunity']['fields']['year_entered_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['year_entered_c']['labelValue']='year entered';

 ?>