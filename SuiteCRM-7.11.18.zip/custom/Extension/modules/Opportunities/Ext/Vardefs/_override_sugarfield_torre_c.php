<?php
 // created: 2021-01-19 20:39:31
$dictionary['Opportunity']['fields']['torre_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['torre_c']['labelValue']='Torre';

 ?>