<?php
 // created: 2020-12-05 23:13:54
$dictionary['Opportunity']['fields']['etapa_de_avaluos_c']['inline_edit']=1;

 ?>