<?php
 // created: 2021-07-28 12:38:27
$dictionary['Opportunity']['fields']['edificio_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['edificio_c']['labelValue']='Edificio';

 ?>