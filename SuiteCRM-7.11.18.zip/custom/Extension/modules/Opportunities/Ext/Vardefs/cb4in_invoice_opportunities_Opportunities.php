<?php
// created: 2020-12-05 22:06:21
$dictionary["Opportunity"]["fields"]["cb4in_invoice_opportunities"] = array (
  'name' => 'cb4in_invoice_opportunities',
  'type' => 'link',
  'relationship' => 'cb4in_invoice_opportunities',
  'source' => 'non-db',
  'module' => 'CB4IN_Invoice',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_CB4IN_INVOICE_OPPORTUNITIES_FROM_CB4IN_INVOICE_TITLE',
);
