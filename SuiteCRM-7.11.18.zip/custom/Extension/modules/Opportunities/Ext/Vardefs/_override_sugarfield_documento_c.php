<?php
 // created: 2020-12-05 23:13:53
$dictionary['Opportunity']['fields']['documento_c']['inline_edit']=1;

 ?>