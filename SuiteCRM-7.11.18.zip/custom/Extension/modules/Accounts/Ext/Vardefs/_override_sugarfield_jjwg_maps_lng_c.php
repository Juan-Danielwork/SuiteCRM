<?php
 // created: 2023-11-11 08:50:04
$dictionary['Account']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>