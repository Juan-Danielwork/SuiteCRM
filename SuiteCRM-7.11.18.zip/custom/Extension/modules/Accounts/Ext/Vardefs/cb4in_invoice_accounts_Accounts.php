<?php
// created: 2020-12-05 22:06:21
$dictionary["Account"]["fields"]["cb4in_invoice_accounts"] = array (
  'name' => 'cb4in_invoice_accounts',
  'type' => 'link',
  'relationship' => 'cb4in_invoice_accounts',
  'source' => 'non-db',
  'module' => 'CB4IN_Invoice',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_CB4IN_INVOICE_ACCOUNTS_FROM_CB4IN_INVOICE_TITLE',
);
