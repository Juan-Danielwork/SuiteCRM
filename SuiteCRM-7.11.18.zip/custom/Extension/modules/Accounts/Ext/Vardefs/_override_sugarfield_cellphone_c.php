<?php
 // created: 2020-12-05 23:13:52
$dictionary['Account']['fields']['cellphone_c']['inline_edit']=1;

 ?>