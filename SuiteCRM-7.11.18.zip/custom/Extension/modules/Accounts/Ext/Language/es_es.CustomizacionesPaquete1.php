<?php 
 // created: 2020-12-05 22:59:14
$mod_strings['LBL_ACCOUNT_INFORMATION'] = 'Información del Cliente';
$mod_strings['LBL_OPPORTUNITIES_SUBPANEL_TITLE'] = 'Avaluos';
$mod_strings['LBL_CELLPHONE'] = 'Telefono Celular';
$mod_strings['LBL_PANEL1'] = 'Nuevo Panel 1';
$mod_strings['LBL_ANY_EMAIL'] = 'Email';
$mod_strings['LBL_STATE'] = 'Provincia';

?>
