<?php
 // created: 2023-11-11 08:50:47
$dictionary['Prospect']['fields']['jjwg_maps_lat_c']['inline_edit']=1;

 ?>