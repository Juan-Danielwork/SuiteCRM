<?php
 // created: 2020-12-10 12:18:39
$layout_defs["SecurityGroups"]["subpanel_setup"]['c2011_payment_securitygroups_1'] = array (
  'order' => 100,
  'module' => 'C2011_Payment',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_C2011_PAYMENT_SECURITYGROUPS_1_FROM_C2011_PAYMENT_TITLE',
  'get_subpanel_data' => 'c2011_payment_securitygroups_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
