<?php
// created: 2020-12-10 12:18:39
$dictionary["SecurityGroup"]["fields"]["c2011_payment_securitygroups_1"] = array (
  'name' => 'c2011_payment_securitygroups_1',
  'type' => 'link',
  'relationship' => 'c2011_payment_securitygroups_1',
  'source' => 'non-db',
  'module' => 'C2011_Payment',
  'bean_name' => 'C2011_Payment',
  'vname' => 'LBL_C2011_PAYMENT_SECURITYGROUPS_1_FROM_C2011_PAYMENT_TITLE',
);
