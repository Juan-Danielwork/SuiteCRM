<?php
 // created: 2023-11-11 08:50:42
$dictionary['Project']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>