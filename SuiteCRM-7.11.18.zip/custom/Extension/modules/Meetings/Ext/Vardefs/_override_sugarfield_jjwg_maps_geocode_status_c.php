<?php
 // created: 2023-11-11 08:50:36
$dictionary['Meeting']['fields']['jjwg_maps_geocode_status_c']['inline_edit']=1;

 ?>