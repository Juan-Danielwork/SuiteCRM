<?php
 // created: 2023-11-11 08:50:37
$dictionary['Meeting']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>