<?php 
 // created: 2020-12-05 22:59:14
$mod_strings['LBL_USER_NAME'] = 'Nombre de Usuario';
$mod_strings['LBL_DEPARTMENT'] = 'Tipo de Sangre';
$mod_strings['LBL_TITLE'] = 'Cedula';

?>
