<?php
// created: 2020-12-10 12:18:39
$dictionary["C2011_Payment"]["fields"]["c2011_payment_securitygroups_1"] = array (
  'name' => 'c2011_payment_securitygroups_1',
  'type' => 'link',
  'relationship' => 'c2011_payment_securitygroups_1',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_C2011_PAYMENT_SECURITYGROUPS_1_FROM_SECURITYGROUPS_TITLE',
);
