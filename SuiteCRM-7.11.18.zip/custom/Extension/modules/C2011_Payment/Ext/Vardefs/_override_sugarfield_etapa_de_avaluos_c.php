<?php
 // created: 2020-12-05 23:13:52
$dictionary['C2011_Payment']['fields']['etapa_de_avaluos_c']['inline_edit']=1;

 ?>