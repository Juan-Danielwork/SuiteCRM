<?php 
 // created: 2020-12-05 22:59:14
$mod_strings['LBL_C2011_PAYMENT_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE'] = 'Numero de Avaluo';
$mod_strings['LBL_ETAPA_DE_AVALUOS'] = 'Etapa de Avaluos';
$mod_strings['LBL_CUENTA'] = 'Cuenta';
$mod_strings['LBL_CLIENTE'] = 'Cliente';
$mod_strings['LBL_AVALUADOR_ASIGNADO'] = 'Avaluador Asignado';

?>
