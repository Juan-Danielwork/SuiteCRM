<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['CA30_Cost'] = 'CA30_Cost';
$beanFiles['CA30_Cost'] = 'modules/CA30_Cost/CA30_Cost.php';
$moduleList[] = 'CA30_Cost';

?>