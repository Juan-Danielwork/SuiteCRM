<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C2011_Payment'] = 'C2011_Payment';
$beanFiles['C2011_Payment'] = 'modules/C2011_Payment/C2011_Payment.php';
$moduleList[] = 'C2011_Payment';

?>