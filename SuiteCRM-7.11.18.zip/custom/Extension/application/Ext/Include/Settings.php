<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['C4SET_Torre'] = 'C4SET_Torre';
$beanFiles['C4SET_Torre'] = 'modules/C4SET_Torre/C4SET_Torre.php';
$moduleList[] = 'C4SET_Torre';
$beanList['C4SET_ITBMS'] = 'C4SET_ITBMS';
$beanFiles['C4SET_ITBMS'] = 'modules/C4SET_ITBMS/C4SET_ITBMS.php';
$moduleList[] = 'C4SET_ITBMS';
$beanList['C4SET_Edificio'] = 'C4SET_Edificio';
$beanFiles['C4SET_Edificio'] = 'modules/C4SET_Edificio/C4SET_Edificio.php';
$moduleList[] = 'C4SET_Edificio';
$beanList['C4SET_Corregimiento'] = 'C4SET_Corregimiento';
$beanFiles['C4SET_Corregimiento'] = 'modules/C4SET_Corregimiento/C4SET_Corregimiento.php';
$moduleList[] = 'C4SET_Corregimiento';
$beanList['C4SET_Barriada'] = 'C4SET_Barriada';
$beanFiles['C4SET_Barriada'] = 'modules/C4SET_Barriada/C4SET_Barriada.php';
$moduleList[] = 'C4SET_Barriada';

?>