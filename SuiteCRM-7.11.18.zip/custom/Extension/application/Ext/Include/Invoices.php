<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['CB4IN_Invoice'] = 'CB4IN_Invoice';
$beanFiles['CB4IN_Invoice'] = 'modules/CB4IN_Invoice/CB4IN_Invoice.php';
$moduleList[] = 'CB4IN_Invoice';

?>