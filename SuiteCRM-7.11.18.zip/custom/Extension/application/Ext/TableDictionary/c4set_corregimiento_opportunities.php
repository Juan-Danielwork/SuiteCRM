<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c4set_corregimiento_opportunitiesMetaData.php');

?>