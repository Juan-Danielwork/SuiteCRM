<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ca30_cost_opportunitiesMetaData.php');

?>