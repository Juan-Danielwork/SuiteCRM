<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/c4set_barriada_opportunitiesMetaData.php');

?>