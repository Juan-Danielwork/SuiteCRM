<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/cb4in_invoice_accountsMetaData.php');

?>