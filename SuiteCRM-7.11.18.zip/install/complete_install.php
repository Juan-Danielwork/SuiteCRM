<?php

ob_clean();
header('Location: index.php?module=Users&action=Login');
