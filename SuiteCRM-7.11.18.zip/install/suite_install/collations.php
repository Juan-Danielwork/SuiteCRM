<?php

$collations = array(
    'mysql' =>
        array(
	    array(
	        'name' => 'utf8_general_ci',
		'charset' => 'utf8',
	    ),
            array(
                'name' => 'utf8mb4_general_ci',
                'charset' => 'utf8mb4',
            ),
        ),
);
