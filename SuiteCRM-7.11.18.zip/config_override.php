<?php
/***CONFIGURATOR***/
$sugar_config['disable_persistent_connections'] = false;
$sugar_config['search']['defaultEngine'] = 'BasicSearchEngine';
$sugar_config['aod']['enable_aod'] = false;
$sugar_config['developerMode'] = true;
// $sugar_config['stack_trace_errors'] = true;

/***CONFIGURATOR***/