<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.11.18';
$suitecrm_timestamp = '2020-11-05 17:00:00';
